<img src="{{ asset('img/logo.png') }}" {{ $attributes }} alt="Logo">
