
<div>
    <p class="mt-2">
        <b class="text-gray-500 text-sm">Desarrollado por: </b>
        <a class="text-gray-400 text-xs underline" href="{{ $companyUrl }}" target="_blank">{{ $companyName }}</a>
    </p>
</div>
